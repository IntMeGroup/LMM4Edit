# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.llm.sampling import sampling_main

if __name__ == '__main__':
    sampling_main()
